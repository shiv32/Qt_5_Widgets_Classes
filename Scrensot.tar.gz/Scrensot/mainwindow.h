#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPixmap>
#include <QWidget>
#include <QTimer>
#include <QtSql>
#include <QSqlDatabase>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

//QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL")
QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");;


QTimer *timer = new QTimer(this);
QTimer *timercount = new QTimer(this);

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
     int counter = 1;
     int flag = 0;
     int count = 0;
     void myshotCount();
     void updateDisplay();
     void autoshot();

private slots:
    void shootScreen();
    void saveScreen();
     void onTimeout();

private slots:
    void on_pushButton_3_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::MainWindow *ui;
    void updateScreenshotLabel();
    QPixmap originalPixmap;
};

#endif // MAINWINDOW_H
