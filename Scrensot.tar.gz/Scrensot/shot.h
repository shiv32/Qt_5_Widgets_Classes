#ifndef SHOT_H
#define SHOT_H


class Shot
{
public:
    Shot();
};

#endif // SHOT_H
