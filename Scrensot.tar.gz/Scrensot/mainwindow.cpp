// Author: Shiv Kumar
//Basic Screeshot Project

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "shot.h"
#include <QDebug>
#include <QString>
#include <QtWidgets>
#include <QMessageBox>
#include <QTimer>
#include <QDateTime>
#include <QX11Info> //for timestamp
#include <QTime>

//#include <QByteArray>
//#include <QBuffer>
#include <QNetworkInterface>

QTime myTimer(0,0,0);

MainWindow::MainWindow(QWidget *parent):
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //ui->label_shot->setText("hello world");

    //db connection

    //remote  MySql connection
    //           db.setHostName("EnterHostName");
    //           //db.setPort(EnterPortNo.);
    //           db.setDatabaseName("EnterDbName");
    //           db.setUserName("EnterUserName");
    //           db.setPassword("EnterPassWord");
    //

    // localhost db connection
    db.setHostName("localhost");
    db.setDatabaseName("qttest");
    db.setUserName("root");
    db.setPassword("root");

    bool ok = db.open();
    if(ok){
        qDebug() <<"connected: " <<ok ;
    }else{
        qDebug() <<"not connected: " <<ok ;

    }
    //for autoshot screen
    //autoshot();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_3_clicked()
{
    //save shot
    QDir dir("/home/userName/Desktop/shot");
    if(!dir.exists()){
        dir.mkpath("/home/userName/Desktop/shot");
    }


    const QString format = "png";
    // QString initialPath = QStandardPaths::writableLocation(QStandardPaths::PicturesLocation);
    QString initialPath;
    //if (initialPath.isEmpty())
    initialPath = "/home/userName/Desktop/shot";
    //initialPath = QDir::currentPath();
    initialPath += tr("/untitled.") + format;

    QFileDialog fileDialog(this, tr("Save As"), initialPath);
    fileDialog.setAcceptMode(QFileDialog::AcceptSave);
    fileDialog.setFileMode(QFileDialog::AnyFile);
    fileDialog.setDirectory(initialPath);

    QStringList mimeTypes;
    foreach (const QByteArray &bf, QImageWriter::supportedMimeTypes())
        mimeTypes.append(QLatin1String(bf));

    fileDialog.setMimeTypeFilters(mimeTypes);
    fileDialog.selectMimeTypeFilter("image/" + format);
    fileDialog.setDefaultSuffix(format);
    if (fileDialog.exec() != QDialog::Accepted)
        return;
    const QString fileName = fileDialog.selectedFiles().first();
    if (!originalPixmap.save(fileName)) {
        QMessageBox::warning(this, tr("Save Error"), tr("The image could not be saved to \"%1\".")
                             .arg(QDir::toNativeSeparators(fileName)));
    }
}

void MainWindow::on_pushButton_clicked()
{
    //start shot
    //QTimer::singleShot(5000, this, SLOT(shootScreen()));

    if(!flag){
        flag = 1;
        connect(timer, SIGNAL(timeout()), this, SLOT(shootScreen()));
    }

    // timer->start(1000);   // 1 sec
    //timer->start(300000);   // 5 min

    // timer->start(60000); // 1 min
    timer->start(10000);   // 10 sec
    if(!count){
        count = 1;
        myshotCount();
    }
}

void MainWindow::shootScreen(){
    //screenshot
    QScreen *screen = QGuiApplication::primaryScreen();
    if (const QWindow *window = windowHandle())
        screen = window->screen();
    if (!screen)
        return;

    originalPixmap = screen->grabWindow(0);
    // updateScreenshotLabel();

    int w = ui->label_shot->width();
    int h = ui->label_shot->height();
    ui->label_shot->setPixmap(originalPixmap.scaled(w,h,Qt::KeepAspectRatio,Qt::SmoothTransformation));

    //save screen
    QDir dir("/home/userName/Desktop/shot");
    if(!dir.exists()){
        dir.mkpath("/home/userName/Desktop/shot");
    }

    //auto fileName = QString("/home/userName/Desktop/shot/desktop_%1.png").arg(counter);
    auto fileName = QString("/home/userName/Desktop/shot/desktop_%1.png").arg(QX11Info::getTimestamp());
    //counter++;
    originalPixmap.save(fileName);

    //insert image in db
    QByteArray inByteArray;
    QBuffer inBuffer(&inByteArray);
    inBuffer.open( QIODevice::WriteOnly );
    originalPixmap.save( &inBuffer, "PNG" ); // write inPixmap into inByteArray in PNG format

    QDateTime datetime=QDateTime::currentDateTime();
    //QString datetimetext=datetime.toString();

    //get system ip
    //QString ipadd = "10.20.30.40";
    QString ipadd;
    foreach (const QHostAddress &address, QNetworkInterface::allAddresses()) {
        if (address.protocol() == QAbstractSocket::IPv4Protocol && address != QHostAddress(QHostAddress::LocalHost))
            ipadd = address.toString();
    }

    QSqlQuery qry;
    qry.prepare("insert into images (ipaddress, image, created) values (:ipaddress, :imageData,:datetime) ");
    qry.bindValue( ":ipaddress", ipadd);
    qry.bindValue( ":imageData", inByteArray);
    qry.bindValue( ":datetime", datetime);
    qry.exec();

}

void MainWindow::saveScreen(){

}

void MainWindow::on_pushButton_2_clicked()
{
    //stop shot
    disconnect(timer, SIGNAL(timeout()), this, SLOT(shootScreen()));
    disconnect(timercount, SIGNAL(timeout()), this, SLOT(onTimeout()));
    flag = 0;
    count = 0;
    ui->label_timer->setText("Recording Stop");
}


void MainWindow::myshotCount(){

    connect(timercount, SIGNAL(timeout()), this, SLOT(onTimeout()));

    timercount->start(1000);
    ui->label_timer->setText(myTimer.toString());
}

void MainWindow::onTimeout()
{
    myTimer = myTimer.addMSecs(timercount->interval());
    updateDisplay();
}

void MainWindow::updateDisplay(){
    ui->label_timer->setText(myTimer.toString("hh:mm:ss"));
}

void MainWindow::autoshot(){
    if(!flag){
        flag = 1;
        connect(timer, SIGNAL(timeout()), this, SLOT(shootScreen()));
    }
    timer->start(1000);
    //timer->start(300000);   // 5 min

    // timer->start(60000);
    if(!count){
        count = 1;
        myshotCount();
    }
}
